let score = 0;
const gameContainer = document.getElementById('game-container');
const ship = document.getElementById('ship'); 
const scoreDisplay = document.getElementById('score-value');
const levelDisplay = document.getElementById('level-value');
const highScoreDisplay = document.getElementById('high-score-value');
const toggleButton = document.getElementById('toggle-button');
const gameOverImage = document.getElementById('game-over-image');
const groundLine = document.getElementById('ground-line'); 

let shipPosition = gameContainer.clientWidth / 2 - 70; 
let gameInterval;
let gameRunning = false;
let paused = false;
let monsters = [];
let level = 1;
let monsterSpeed = 5;
let monsterSpawnInterval = 1500;
let highScore = localStorage.getItem('highScore') || 0;

highScoreDisplay.textContent = highScore;

const missileSound = new Audio('https://universal-soundbank.com/sounds/2206.mp3');
const explosionSound = new Audio('https://universal-soundbank.com/sounds/2199.mp3');
const gameOverSound = new Audio('https://universal-soundbank.com/sounds/4073.mp3');
const pauseSound = new Audio('https://universal-soundbank.com/sounds/2201.mp3');

const monsterImageUrl = 'https://imgur.com/k8gH64Z.png';

function createMonster() {
    const monster = document.createElement('div');
    monster.className = 'monster';
    monster.style.backgroundImage = `url(${monsterImageUrl})`; 
    monster.style.backgroundSize = 'contain';
    monster.style.backgroundRepeat = 'no-repeat';
    monster.style.left = `${Math.random() * (gameContainer.clientWidth - 120)}px`;
    monster.style.top = '0px'; 
    gameContainer.appendChild(monster);
    monsters.push(monster);

    moveMonster(monster);
}

function moveMonster(monster) {
    const interval = setInterval(() => {
        if (!gameRunning) return;

        const currentTop = parseInt(monster.style.top || 0);
        monster.style.top = `${currentTop + monsterSpeed}px`;

        const monsterRect = monster.getBoundingClientRect();
        const shipRect = ship.getBoundingClientRect(); 
        const groundLineRect = groundLine.getBoundingClientRect(); 

        const isCollidingWithShip = 
            monsterRect.bottom >= shipRect.top && 
            monsterRect.top <= shipRect.bottom && 
            monsterRect.right >= shipRect.left && 
            monsterRect.left <= shipRect.right;

        if (isCollidingWithShip) {
            endGame(); 
        }

        const isCollidingWithGround = monsterRect.bottom >= groundLineRect.top;

        if (isCollidingWithGround) {
            endGame(); 
        }

        if (currentTop > gameContainer.clientHeight) {
            monster.remove();
            monsters = monsters.filter(m => m !== monster);
        }
    }, 50);

    monster.monsterInterval = interval;
}

function shootMissile() {
    const missile = document.createElement('div');
    missile.className = 'missile';
    missile.style.left = `${shipPosition + 50}px`; 
    missile.style.bottom = '140px'; 
    gameContainer.appendChild(missile);
    moveMissile(missile);

    missileSound.play();
}

function moveMissile(missile) {
    const interval = setInterval(() => {
        if (!gameRunning) return;

        const currentBottom = parseInt(missile.style.bottom || 0);
        missile.style.bottom = `${currentBottom + 10}px`;

        const missileRect = missile.getBoundingClientRect();
        const monstersCopy = [...monsters];

        for (let monster of monstersCopy) {
            const monsterRect = monster.getBoundingClientRect();
            
            const isColliding = 
                missileRect.bottom <= monsterRect.bottom &&
                missileRect.top >= monsterRect.top &&
                missileRect.right >= monsterRect.left &&
                missileRect.left <= monsterRect.right;

            if (isColliding) {
                score++;
                scoreDisplay.innerText = score;
                levelDisplay.innerText = level;

                if (score > highScore) {
                    highScore = score;
                    highScoreDisplay.innerText = highScore;
                    localStorage.setItem('highScore', highScore);
                }

                explosionSound.play();

                monster.remove();
                missile.remove();
                clearInterval(missile.missileInterval);
                monsters = monsters.filter(m => m !== monster);

                // Niveau augmente tous les 60 points
                if (score > 0 && score % 60 === 0) {
                    levelUp();
                }

                return;
            }
        }

        if (currentBottom > gameContainer.clientHeight) {
            clearInterval(missile.missileInterval);
            missile.remove();
        }
    }, 20);

    missile.missileInterval = interval;
}

function levelUp() {
    level++; 
    monsterSpeed += 1; 
    monsterSpawnInterval = Math.max(500, monsterSpawnInterval - 100); 

    levelDisplay.innerText = level; 

    clearInterval(gameInterval); 
    gameInterval = setInterval(createMonster, monsterSpawnInterval);
}

function endGame() {
    gameRunning = false;
    paused = false; 
    clearInterval(gameInterval);
    monsters.forEach(monster => {
        clearInterval(monster.monsterInterval);
        monster.remove();
    });
    monsters = [];

    gameOverSound.play();

    if (score > highScore) {
        highScore = score;
        highScoreDisplay.innerText = highScore;
        localStorage.setItem('highScore', highScore);
    }

    gameOverImage.style.display = 'block'; 
    gameOverImage.classList.remove('hidden');

    toggleButton.innerText = "Start";
    score = 0;
    scoreDisplay.innerText = score;
    level = 1;
    monsterSpeed = 5;
    monsterSpawnInterval = 1500;
}

toggleButton.addEventListener('click', () => {
    if (!gameRunning && !paused) {
        score = 0;
        scoreDisplay.innerText = score;
        level = 1;
        levelDisplay.innerText = level;

        monsterSpeed = 5;
        monsterSpawnInterval = 1500;

        gameRunning = true;
        paused = false;
        toggleButton.innerText = "Pause";
        gameOverImage.classList.add('hidden');
        gameOverImage.style.display = 'none';

        gameInterval = setInterval(createMonster, monsterSpawnInterval);
    } else if (gameRunning && !paused) {
        gameRunning = false;
        paused = true;
        toggleButton.innerText = "Reprendre";

        pauseSound.play();

        clearInterval(gameInterval);
    } else if (paused) {
        gameRunning = true;
        paused = false;
        toggleButton.innerText = "Pause";

        pauseSound.play();

        gameInterval = setInterval(createMonster, monsterSpawnInterval);
    }
});

// Gestion du mouvement du vaisseau
document.addEventListener('touchmove', (event) => {
    if (gameRunning) {
        const touch = event.touches[0];
        const containerRect = gameContainer.getBoundingClientRect();
        shipPosition = touch.clientX - containerRect.left - 70; // 70px correspond à la moitié de la largeur du vaisseau

        // Limiter le mouvement du vaisseau
        shipPosition = Math.max(0, Math.min(shipPosition, gameContainer.clientWidth - 140)); // 140px correspond à la largeur du vaisseau

        ship.style.left = `${shipPosition}px`;
    }
});

// Gestion du tir de missile
document.addEventListener('touchstart', (event) => {
    if (gameRunning) {
        shootMissile();
    }
});